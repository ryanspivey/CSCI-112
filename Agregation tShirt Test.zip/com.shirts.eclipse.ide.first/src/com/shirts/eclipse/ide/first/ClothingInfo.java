package com.shirts.eclipse.ide.first;

public class ClothingInfo {
//instance fields
	private String clothingName;
	private String colorWay;
	
	//constructors
	public ClothingInfo(String name, String color) {
		clothingName= name;
		colorWay= color;
	}
	
	//overloaded constructor
	public ClothingInfo(ClothingInfo object2) {
		clothingName= object2.clothingName;
		colorWay= object2.colorWay;
	}
	
	//get
	
	//set
	public void set(String name, String color) {
		clothingName= name;
		colorWay= color;
	}
	
	public String toString() {
		String str= "\n\tArticle: " + clothingName + "\n\tColorway: " + colorWay;
		return str;
	}
}
