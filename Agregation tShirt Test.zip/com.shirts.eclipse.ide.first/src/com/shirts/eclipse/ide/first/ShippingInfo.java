package com.shirts.eclipse.ide.first;

public class ShippingInfo {
//instance fields
	private String boxSize;
	private String boxWeight;
	
	//constructor
	public ShippingInfo(String size, String weight) {
		boxSize= size;
		boxWeight= weight;
	}
	
	//overload constructor
	public ShippingInfo(ShippingInfo object2) {
		boxSize= object2.boxSize;
		boxWeight= object2.boxWeight;
	}
	
	//get
	
	//set
	public void set(String size, String weight) {
		boxSize= size;
		boxWeight= weight;
	}
	
	public String toString() {
		String str= "\n\tBox Dimensions: " + boxSize + "\n\tBox Weight: " + boxWeight;
		return str;
	}
}
