package com.shirts.eclipse.ide.first;

public class ClothingDemo {
	public static void main(String[] args) {
		ClothingInfo SkablurbTeeBlue= new ClothingInfo("Skablurb Tee", "Blue Tie-Dye");
		ShippingInfo SkablurbShip= new ShippingInfo("9x13x2", "1.13 lbs");
		ClothingItem SkablurbTeeBlueTieDye= new ClothingItem(SkablurbTeeBlue, SkablurbShip);
		
		System.out.println(SkablurbTeeBlueTieDye);
		
	}
}
