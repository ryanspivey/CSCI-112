package com.shirts.eclipse.ide.first;

public class ClothingItem {
public ClothingInfo ClothingInfo;
public ShippingInfo ShippingInfo;

//constructor
public ClothingItem(ClothingInfo clothinfo, ShippingInfo shipinfo) {
	ClothingInfo= clothinfo;
	ShippingInfo= shipinfo;
}

//getters
public ClothingInfo getClothingInfo() {
	return new ClothingInfo(ClothingInfo);
}
public ShippingInfo getShippingInfo() {
	return new ShippingInfo(ShippingInfo);
}

//toString
public String toString() {
	String str= "\n\tClothing Specifics: " + ClothingInfo + "\n\tShipping Info: " + ShippingInfo;
	return str;
}
	
}
