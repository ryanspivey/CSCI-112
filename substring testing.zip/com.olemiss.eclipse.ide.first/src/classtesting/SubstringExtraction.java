package classtesting;

public class SubstringExtraction {
	public static void main(String[]args) {
String str= "Mary Susan Smith";

int space1= str.indexOf(" ");
int space2= str.lastIndexOf(" ");

String first= str.substring(0, space1);

String middle= str.substring(space1 + 1, space2);

String last= str.substring(space2 + 1);


System.out.println("First: " + first);
System.out.println("Middle: " + middle);
System.out.println("Last: " + last);
	}
}
