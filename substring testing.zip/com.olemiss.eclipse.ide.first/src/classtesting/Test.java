package classtesting;

public class Test {

	public static void main(String[] args) {
		
		//indexOf eg
		String str= "Four score and seven years ago";
		System.out.println("The letter r appears at the fllowing locations: ");
		int position= str.indexOf('r');
		while(position != -1) {
			System.out.println(position);
			position= str.indexOf('r', position + 1);
			
		}
		
		//indexOf eg
		String str2= "and a one and a two and a three";
		int positionAnd= str2.indexOf("and");
		while (positionAnd != -1) {
			System.out.println(positionAnd);
			positionAnd= str2.indexOf("and", positionAnd + 1);
		}
	}

}
