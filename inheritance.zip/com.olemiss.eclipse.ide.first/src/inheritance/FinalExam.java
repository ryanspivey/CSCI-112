package inheritance;

public class FinalExam extends GradedActivity{
	private int numQuestions;
	private int numMissed;
	
	public FinalExam(int questions, int missed) {
		numQuestions= questions;
		numMissed= missed;
		
		double pointsEachQuestions= 100.0/questions;
		double numericScore = 100 - pointsEachQuestions * missed;
		setScore(numericScore);
	}
	
	//getNumQ getter
	public int getNumQuestions() {
		return numQuestions;
	}
	//getNumQ setter
	public void setNumQuestions(int numQuestions) {
		this.numQuestions = numQuestions;
	}
	//getNumMissed getter
	public int getNumMissed() {
		return numMissed;
	}
	//getNumMissed setter
	public void setNumMissed(int numMissed) {
		this.numMissed = numMissed;
	}
}
