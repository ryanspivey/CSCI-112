package inheritance;
import java.util.*;

public class GradedActivityDemo {
	public static void main(String []args) {
	Scanner scan= new Scanner(System.in);
	GradedActivity activity= new GradedActivity();
	System.out.print("Enter a grade: ");
	double score= scan.nextInt();
	
	activity.setScore(score);
	System.out.println(activity.getScore() + " & " + activity.getGrade());
	scan.close();
	}
	
}
